extends ProgressBar

func _ready():
	value = 0
	max_value = 100

func _process(_delta):
	if value < max_value:
		value += 15
	else:
		get_tree().change_scene_to_file("res://node_2d.tscn")
