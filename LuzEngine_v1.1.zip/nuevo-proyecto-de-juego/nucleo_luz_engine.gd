extends ProgressBar

func _ready():
	value = 0

func _process(_delta):
	if value < max_value:
		value += 15  # Más número = más rápido
	else:
		get_tree().change_scene_to_file("res://node_2d.tscn")
