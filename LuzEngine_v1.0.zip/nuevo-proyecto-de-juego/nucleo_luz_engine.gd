extends Node

# Enlazamos los nodos que ya tienes listos
@onready var barra_carga = $Cargando
@onready var comprobar_red = $HTTPRequest

var progreso = 0.0

func _ready():
	print("✅ LuzEngine Nucleo iniciado")
	# Conectamos la respuesta de internet
	comprobar_red.request_completed.connect(_respuesta_de_red)
	# Empezamos a revisar si hay conexion
	comprobar_red.request("https://1.1.1.1")

func _process(delta):
	# Avanzamos la barra de carga
	if progreso < 100:
		progreso += 15 * delta
		barra_carga.value = progreso
	else:
		barra_carga.value = 100
		# Cambiamos automaticamente al mundo 3D
		get_tree().change_scene_to_file("res://mundo_3d.tscn")

# Funcion que avisa si hay internet o no
func _respuesta_de_red(resultado, codigo, cuerpo, tipo):
	if resultado == OK:
		print("🌐 Conexion a internet: ACTIVA")
	else:
		print("⚠️ Sin conexion: modo sin internet activado")
